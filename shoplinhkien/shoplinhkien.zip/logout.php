<?php
session_start();

// Hủy tất cả các session
session_destroy();

// Chuyển hướng về trang đăng nhập
header("Location: login.php");
exit();
?> 